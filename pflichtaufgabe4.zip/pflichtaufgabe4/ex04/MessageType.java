package ex04;

public enum MessageType {
    Call,
    Response
}
